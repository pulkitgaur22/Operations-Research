%% this script is used for plot the portfolio values for the five selected trading strategies

% Input file names
porfolioData  = 'Champion Candidates portfValue.xlsx';
factorData = 'MMF1921_FactorReturns2.csv';

porfolioValues = xlsread(porfolioData);
tags = {'MVO*' 'RP*' 'Robust MVO*' 'Momentum*' 'Volatility*' 'EqualWeight portfolio'};

% Load the stock weekly prices
adjClose = readtable(assetData);
adjClose.Properties.RowNames = cellstr(datetime(adjClose.Date));
adjClose.Properties.RowNames = cellstr(datetime(adjClose.Properties.RowNames));
adjClose.Date = [];

% Load the factors weekly returns
factorRet = readtable(factorData);
factorRet.Properties.RowNames = cellstr(datetime(factorRet.Date));
factorRet.Properties.RowNames = cellstr(datetime(factorRet.Properties.RowNames));
factorRet.Date = [];

% Calculate the stocks' weekly EXCESS returns
prices  = table2array(adjClose);
returns = ( prices(2:end,:) - prices(1:end-1,:) ) ./ prices(1:end-1,:);
returns = returns - ( diag( table2array(riskFree) ) * ones( size(returns) ) );
returns = array2table(returns);
returns.Properties.VariableNames = tickers;
returns.Properties.RowNames = cellstr(datetime(factorRet.Properties.RowNames));


dates   = datetime(factorRet.Properties.RowNames);

plotDates = dates(dates  >= datetime(returns.Properties.RowNames{1}) + calyears(5) );

fig1 = figure(1);

for i = 1 : 6
    
    plot( plotDates, porfolioValues(2:end,i) )
    hold on
    
end

legend(tags, 'Location', 'eastoutside','FontSize',12);
datetick('x','dd-mmm-yyyy','keepticks','keeplimits');
set(gca,'XTickLabelRotation',30);
title('Portfolio value', 'FontSize', 14)
ylabel('Value','interpreter','latex','FontSize',12);

% Define the plot size in inches
set(fig1,'Units','Inches', 'Position', [0 0 8, 5]);
pos1 = get(fig1,'Position');
set(fig1,'PaperPositionMode','Auto','PaperUnits','Inches',...
    'PaperSize',[pos1(3), pos1(4)]);

% If you want to save the figure as .pdf for use in LaTeX
print(fig1,'PortfValue of Candidate','-dpdf','-r0');