function x = maxSharpe(stockRet)
% Get maximum sharpe
%   Input: 
%       stockRet: Monthly return of stocks for a given period
%       riskFree: Monthly risk-free return for the same period
%   Output:
%       x: One single weight vector optimized with all data
    H=cov(stockRet.Variables);
    Aeq = mean(stockRet.Variables,1);
    beq = 1;
    lb = zeros(size(Aeq,2),1);
    options = optimoptions('quadprog','TolFun',1e-30,'Display','off');
    x = quadprog(H,[],[],[],Aeq,beq,lb,[],[],options);
    x = x/sum(x);
end

