function obj = obj_ssk(x,stockRet,a_skew,a_kurt)
%Objective function of Sharp_skewness_kurtosis optimization
%   Input: 
%       x: Weight
%       stockRet: Monthly return of stocks for a given period
%       riskFree: Monthly risk-free return for the same period
%       a_skew: penalty coefficient for skewness
%       a_kurt: penalty coefficient for kurtosis
%   Output:
%       obj: the value of the objective function
    portRet=stockRet.Variables*x;
    portSharp=mean(portRet)/std(portRet);
    %portSkew=skewness(portRet);
    %portKurt=kurtosis(portRet);
    obj=-portSharp-a_skew*skewness(portRet)+a_kurt*(kurtosis(portRet)-3);
end

