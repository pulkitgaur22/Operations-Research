function [mu, Q, R_squre_adj] = Historical(returns, factRet, lambda, K)
% just return the mean of historical returns and the convariance matirx

    mu =  mean(returns)';       % n x 1 vector of asset exp. returns
    Q  =  cov(returns);       % n x n asset covariance matrix
    R_squre_adj = 0;
end

