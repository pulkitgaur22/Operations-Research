function  [finalWeights] = Momentum(relevantReturns,stockPrices,proportion,a_skew,a_kurt)
    warning('off');
    tickers=stockPrices.Properties.VariableNames;
    relevantPrices =  table2array( stockPrices);         
    nrow=size(relevantPrices,1);       
    
    %Momentum is calculated as the 12 month return, excluding the last
    %month for short term reversals
    momentum = (relevantPrices(nrow-1,:)./relevantPrices(nrow-12,:))*100;
    
    %Find the top10 and bottom10 momentum stocks
    numberofStocks=size(relevantPrices,2);
    topNumber=round(numberofStocks/2);
    [B,I1]=maxk(momentum,topNumber);
    [B,I2]=mink(momentum,numberofStocks-topNumber);
    
    
    %find the names of the stocks in two buckets
    top10= stockPrices.Properties.VariableNames(I1);
    bottom10= stockPrices.Properties.VariableNames(I2);
    
    
    %subset their data for optimisation
    dataHighMomentum = relevantReturns{:,top10};
    dataLowMomentum = relevantReturns{:,bottom10};
    
    % Models selection and combination part
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %using risk parity for high momentum stocks
    Q1=cov(dataHighMomentum);
    w1= RP(Q1);
    %using cVaR for high momentum stocks
%     w1=CVaR(dataHighMomentum);
    %using max_sharpe for high momentum stocks
%     w1= maxSharpe(array2table(dataHighMomentum));
    %using maxSharpeSkew for high momentum stocks
%     w1=Sharp_skew_kurt(array2table(dataHighMomentum),a_skew,a_kurt);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %using cVaR for low momentum stocks
    Q2=cov(dataLowMomentum);
    mu2=mean(dataLowMomentum);
    w2=CVaR(dataLowMomentum);
    
%     w2= RP(Q2);
    %using maxSharpe for low momentum stocks
%     w2=maxSharpe(array2table(dataLowMomentum));
    
    %using maxSharpeSkew for low momentum stocks
%     w2=Sharp_skew_kurt(array2table(dataLowMomentum),a_skew,a_kurt);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
    %distributing the weights as per the proportion of two buckets
    weights1=w1*proportion;
    weights2=w2*(1-proportion);
    
    finalWeights=zeros(numberofStocks,1);
    
    %attaching the right weight to each stock
    for i=1:size(tickers,2)
        st=tickers(i);
        if ismember(st,top10)
            [a b]=ismember(st,top10);
            reqWeight=weights1(b);
        else
            [a b]=ismember(st,bottom10);
            reqWeight=weights2(b);
        end
        finalWeights(i)=reqWeight;
    end
    
    
    











