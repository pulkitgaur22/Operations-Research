function x = Sharp_skew_kurt(stockRet,a_skew,a_kurt)
% Get maximum sharpe when penalize the skewness and kurtosis
%   Input: 
%       stockRet: Monthly return of stocks for a given period
%       riskFree: Monthly risk-free return for the same period
%       a_skew: penalty coefficient for skewness
%       a_kurt: penalty coefficient for kurtosis
%   Output:
%       x: One single weight vector optimized with all data
    Aeq=ones(size(stockRet,2),1).';
    beq=1;
    lb=zeros(size(stockRet,2),1);
    x0=(1+lb)/length(lb);
    fun = @(x)obj_ssk(x,stockRet,a_skew,a_kurt);
    options = optimoptions('fmincon','TolFun',1e-30,'Display','off');

    x = fmincon(fun,x0,[],[],Aeq,beq,lb,[],[],options);

end

