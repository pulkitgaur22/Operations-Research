function [mu, Q, R_squre_adj] = EqualWeight(returns, factRet, lambda, K)
mu=0;
Q=0;
R_squre_adj=0;
end

